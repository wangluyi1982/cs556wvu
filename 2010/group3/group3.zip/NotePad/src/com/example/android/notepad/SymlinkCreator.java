package com.example.android.notepad;

import java.io.IOException;
import java.io.PrintWriter;

public class SymlinkCreator
{
	private Process process;
	private PrintWriter out;
	
	public SymlinkCreator( String path ) throws IOException
	{
        process = Runtime.getRuntime().exec(path);
        out = new PrintWriter(process.getOutputStream());
	}
	
	public void link( String oldpath, String newpath )
	{
        out.println(oldpath);
        out.println(newpath);
        out.flush();
	}
	
	public void terminate() throws InterruptedException
	{
        out.close();
        process.waitFor();
        process.destroy();
	}
}
