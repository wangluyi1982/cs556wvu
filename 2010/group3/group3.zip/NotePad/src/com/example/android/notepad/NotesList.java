/*
 * Copyright (C) 2007 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.example.android.notepad;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.AddAxiom;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLException;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.util.SimpleIRIMapper;

import android.app.AlertDialog;
import android.app.ListActivity;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
//import android.os.Environment;
import android.text.Editable;
import android.util.Log;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;

import com.example.android.notepad.NotePad.Notes;

/**
 * Displays a list of notes. Will display notes from the {@link Uri}
 * provided in the intent if there is one, otherwise defaults to displaying the
 * contents of the {@link NotePadProvider}
 */
public class NotesList extends ListActivity {
    private static final String TAG = "NotesList";

    // Menu item ids
    public static final int MENU_ITEM_DELETE = Menu.FIRST;
    public static final int MENU_ITEM_INSERT = Menu.FIRST + 1;
    public static final int MENU_ITEM_EXPORT = Menu.FIRST + 2;
    public static final int MENU_ITEM_SCAN = Menu.FIRST + 3;
    public static final int MENU_ITEM_SHOWFILES = Menu.FIRST + 4;

    /**
     * The columns we are interested in from the database
     */
    private static final String[] PROJECTION = new String[] {
            Notes._ID, // 0
            Notes.TITLE, // 1
    };

    /** The index of the title column */
    private static final int COLUMN_INDEX_TITLE = 1;
    private static long parent_id = -1;
    private static String parent_node = "Root";
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setDefaultKeyMode(DEFAULT_KEYS_SHORTCUT);

        // If no data was given in the intent (because we were started
        // as a MAIN activity), then use our default content provider.
        Intent intent = getIntent();
        String SELECTION = null;
        if (intent.getData() == null) { 
            intent.setData(Notes.CONTENT_URI);
            Bundle res = intent.getExtras();
            if (res != null){
            	parent_id = res.getLong("id");
            	parent_node = res.getString("parent");
            }
            	
            SELECTION = "_id IN (SELECT child FROM Relationships WHERE parent = " + parent_id + ")";
        }
        
      
        // Inform the list we provide context menus for items
        getListView().setOnCreateContextMenuListener(this);
        
        // Perform a managed query. The Activity will handle closing and requerying the cursor
        // when needed.
        Cursor cursor = managedQuery(getIntent().getData(), PROJECTION, SELECTION, null,
                Notes.DEFAULT_SORT_ORDER);
        

        // Used to map notes entries from the database to views
        SimpleCursorAdapter adapter = new SimpleCursorAdapter(this, R.layout.noteslist_item, cursor,
                new String[] { Notes.TITLE }, new int[] { android.R.id.text1 });
        setListAdapter(adapter);
        
        // if no node has been added yet, show introduction message
        if (managedQuery(getIntent().getData(), new String[] {"title"}, "_id = -1", null, null) == null){
        	showToast("Welcome! Click 'Add Node' from the menu to create your Ontology", 2);
        }
        
        if (parent_id == -1){
        	//CreateFile();
        	GetNewFiles();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);

        // This is our one standard application action -- inserting a
        // new note into the list.
        menu.add(0, MENU_ITEM_INSERT, 0, R.string.menu_insert)
                .setShortcut('3', 'a')
                .setIcon(android.R.drawable.ic_menu_add);
        
        menu.add(1, MENU_ITEM_EXPORT, 0, "Export OWL")
        		.setShortcut('4', 'e')
        		.setIcon(android.R.drawable.ic_menu_save);
        
        menu.add(2, MENU_ITEM_SCAN, 0, "Scan")
        		.setShortcut('5', 's')
        		.setIcon(android.R.drawable.ic_menu_rotate);

        // Generate any additional actions that can be performed on the
        // overall list.  In a normal install, there are no additional
        // actions found here, but this allows other applications to extend
        // our menu with their own actions.
        Intent intent = new Intent(null, getIntent().getData());
        intent.addCategory(Intent.CATEGORY_ALTERNATIVE);
        menu.addIntentOptions(Menu.CATEGORY_ALTERNATIVE, 0, 0,
                new ComponentName(this, NotesList.class), null, intent, 0, null);

        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        super.onPrepareOptionsMenu(menu);
        final boolean haveItems = getListAdapter().getCount() > 0;

        // If there are any notes in the list (which implies that one of
        // them is selected), then we need to generate the actions that
        // can be performed on the current selection.  This will be a combination
        // of our own specific actions along with any extensions that can be
        // found.
        if (haveItems) {
            // This is the selected item.
            Uri uri = ContentUris.withAppendedId(getIntent().getData(), getSelectedItemId());

            // Build menu...  always starts with the EDIT action...
            Intent[] specifics = new Intent[1];
            specifics[0] = new Intent(Intent.ACTION_EDIT, uri);
            MenuItem[] items = new MenuItem[1];

            // ... is followed by whatever other actions are available...
            Intent intent = new Intent(null, uri);
            intent.addCategory(Intent.CATEGORY_ALTERNATIVE);
            menu.addIntentOptions(Menu.CATEGORY_ALTERNATIVE, 0, 0, null, specifics, intent, 0,
                    items);

            // Give a shortcut to the edit action.
            if (items[0] != null) {
                items[0].setShortcut('1', 'e');
            }
        } else {
            menu.removeGroup(Menu.CATEGORY_ALTERNATIVE);
        }

        return true;
    }
    
    /**
     * Displays a brief notification for x amount of time
     * @param text message to be displayed in notification
     * @param time duration of the notification (in millseconds)
     */
    public void showToast(String text, Integer time){    	
  	  Context context = getApplicationContext();
	  CharSequence txt = text;
	  int duration = Toast.LENGTH_SHORT;
	  if (time != null){
		  duration = time;
	  }
  	  Toast toast = Toast.makeText(context, txt, duration);
	  toast.show();
    }
    
    
    /**
     * Exports the data stored in database to an OWL file
     * @param path where the owl file will be stored.
     * @throws SQLException
     */
	public void SaveOWL(String path) throws SQLException{

        try {
            // Create the manager that we will use to load ontologies.
            OWLOntologyManager manager = OWLManager.createOWLOntologyManager();

            // Specify IRI used to identify the ontology
            IRI ontologyIRI = IRI.create("http://code.google.com/p/cs556grp3/ontology.owl");
            
            // Create the document IRI for our ontology
            showToast("Exporting to '" + path + "'", 3);
            
            path = "file:/" + path;
            IRI documentIRI = IRI.create(path);
            
            // Set up a mapping, which maps the ontology to the document IRI
            SimpleIRIMapper mapper = new SimpleIRIMapper(ontologyIRI, documentIRI);
            manager.addIRIMapper(mapper);

            // Now create the ontology - we use the ontology IRI (not the physical URI)
            OWLOntology ontology = manager.createOntology(ontologyIRI);
            
            OWLDataFactory factory = manager.getOWLDataFactory();
            
            // Parent-Child ids from the Relationships table
            ContentResolver contresolver = getContentResolver();
            Cursor c = contresolver.query(getIntent().getData(), new String[] {"parent", "child"}, null, null, "Relationships");
    		String parent = null, child = null, pid, cid;
    		OWLClass clsA = null, clsB;
    		Cursor x;
    		
    		// for each relationship, create a B is a subclass of A relationship
    		if (c != null){
    			c.moveToFirst();
    			int pndx = c.getColumnIndex("parent");
    			int cndx = c.getColumnIndex("child");
    			
    			while (c.isAfterLast() == false){
    				pid = c.getString(pndx);
    				cid = c.getString(cndx);
    				
    				x = contresolver.query(getIntent().getData(), new String[] {"title"}, "_id=" + pid, null, null);
    				if (x != null && x.getCount() > 0){
    					x.moveToFirst();
    					parent = x.getString(x.getColumnIndex("title"));
    				}
    				
    				x = contresolver.query(getIntent().getData(), new String[] {"title"}, "_id=" + cid, null, null);
    				if (x != null && x.getCount() > 0){
    					x.moveToFirst();
    					child = x.getString(x.getColumnIndex("title"));
    				}
    				
    				if (parent != null && child != null){
		    			clsA = factory.getOWLClass(IRI.create(ontologyIRI + "#" + child));
		    			clsB = factory.getOWLClass(IRI.create(ontologyIRI + "#" + parent));
		    			
			            // Now create the axiom
			            OWLAxiom axiom = factory.getOWLSubClassOfAxiom(clsA, clsB);
		
			            // Add the Axiom to the Ontology
			            AddAxiom addAxiom = new AddAxiom(ontology, axiom);
			   
			            // Use the manager to apply changes
			            manager.applyChange(addAxiom);
		    		
			            // We should also find that B is an ASSERTED superclass of A
			            Set<OWLClassExpression> superClasses = clsA.getSuperClasses(ontology);
			            System.out.println("Asserted superclasses of " + clsA + ":");
			            for (OWLClassExpression desc : superClasses) {
			                System.out.println(desc);
			            }
			            
			            // get any actual files the child has and add it as well
			            String f;
			            Cursor y = contresolver.query(getIntent().getData(), new String[] {"filename"}, "pid=" + cid, null, "Dirs_Files");
			            if (y != null){
			            	if (y.getCount() > 0){
				            	y.moveToFirst();
				            	while (y.isAfterLast() == false){
				            		f = y.getString(y.getColumnIndex("filename"));
				            		
				            		// create the classes
					    			clsA = factory.getOWLClass(IRI.create(ontologyIRI + "#" + f));
					    			clsB = factory.getOWLClass(IRI.create(ontologyIRI + "#" + child));
					    			
						            // Now create the axiom
						            axiom = factory.getOWLSubClassOfAxiom(clsA, clsB);
					
						            // Add the Axiom to the Ontology
						            addAxiom = new AddAxiom(ontology, axiom);
						   
						            // Use the manager to apply changes
						            manager.applyChange(addAxiom);
					    		
						            // We should also find that B is an ASSERTED superclass of A
						            superClasses = clsA.getSuperClasses(ontology);
						            System.out.println("Asserted superclasses of " + clsA + ":");
						            for (OWLClassExpression desc : superClasses) {
						                System.out.println(desc);
						            }
						            y.moveToNext();
				            	}
			            	}
			            }
    				}
		            c.moveToNext();
    			}
    		}
    		
    		// The ontology will now contain references to class A and class B 
            for (OWLClass cls : ontology.getClassesInSignature()) {
                System.out.println("Referenced class: " + cls);
            }

            // Now save the ontology (overwrite if file already exists). 
            manager.saveOntology(ontology);

        }
        catch (OWLException e) {
            e.printStackTrace();
        }
	}
    
	/**
	 * Provides the user with an interface for adding new nodes to the Ontology
	 */
    public void NewNode(){
    	AlertDialog.Builder alert = new AlertDialog.Builder(this);

    	alert.setTitle("New Node");
    	if (parent_node == "Root"){
    		alert.setMessage("Add root node");
    	}else{
    		Cursor c = getContentResolver().query(getIntent().getData(), new String[] {"title"}, "_id = " + parent_id, null, null);
    		c.moveToFirst();
    		alert.setMessage("Add new node under " + c.getString(c.getColumnIndex("title")));
    	}

    	// Set an EditText view to get user input 
    	final EditText input = new EditText(this);
    	alert.setView(input);

    	alert.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
    	public void onClick(DialogInterface dialog, int whichButton) {
    	  Editable value = input.getText();
    	  // Do something with value!
    	  // insert into the Ontology table
    	  String new_node = "";
    	  ContentValues values = new ContentValues();
    	  new_node = value.toString();
    	  values.put("title", new_node);
    	  Uri r = getContentResolver().insert(getIntent().getData(), values);
    	  
    	  // add relationship to Relationships table...node is child of parent_id
    	  values.clear();
    	  values.put("node_name", new_node);
    	  values.put("parent", parent_id);
    	  values.put("child", r.getLastPathSegment()); // r.getLastPathSegment gives you the id of the node just added
    	  getContentResolver().insert(getIntent().getData(), values);
    	  values.clear();
    	  
    	  showToast("'" + new_node + "' has been added", null);
    	  }
    
    	});

    	alert.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
    	  public void onClick(DialogInterface dialog, int whichButton) {
    	    // Canceled.
    	  }
    	});

    	alert.show();

    }
    
    
    /**
     * Given a list of keywords, this function iterates through all the paths in the relationship table
     * and returns the best matching path
     * @param keywords list of words that would be used to determine best path
     * @return
     */
    public String[] BestPath(String[] keywords){
    	String curr_path = null, best_path = null;
    	String[] c_path;
    	int count = 0, highest = -1;
    	String dir = "";
    	Cursor c = getContentResolver().query(getIntent().getData(), new String[] {"child", "path"}, null, null, "Relationships");
    	if (c != null){
    		c.moveToFirst();
    		while(c.isAfterLast() == false){
    			curr_path = c.getString(c.getColumnIndex("path"));
    			c_path = curr_path.split("/");
    			count = 0;
    			for (int i = 0; i < keywords.length; i++){
    				for (int j = 0; j < c_path.length; j++){
    					if (keywords[i].equalsIgnoreCase(c_path[j])){
    						count++;
    					}
    				}
    			} 
        		if (count > highest){
    				highest = count;
    				best_path = curr_path;
    				dir = c.getString(c.getColumnIndex("child"));
    			} 
        		c.moveToNext();
    		}  
    	}
    	return new String[] {dir, best_path};
    }
    
    
	/**
	 * Converts the first character of each word in the given string to upper case
	 * and replaces spaces with underscores
	 * @param str - String of words
	 * @return newword - String of words with first character of each word converted to upper case
	 */
	public String CapWords(String str){
		String[] words = str.split(" ");
		String tmp, newword = "";
		for (int i = 0; i < words.length; i++){
			tmp = words[i];
			newword += tmp.substring(0,1).toUpperCase() + tmp.substring(1).toLowerCase();
			if (i == (words.length - 2)){
				newword += " ";
			}
		}
		return newword.replace(" ", "_");
	}
    
	
	/**
	 * Extracts a set of keywords from a given file
	 * @param file data file from which keywords will be extracted
	 * @return array of keywords (as strings)
	 */
	public String[] ExtractKeywords(String file){
		String[] keywords = null;
		try{
			FileReader input = new FileReader(file);
	        
			BufferedReader bufRead = new BufferedReader(input);
	        String line; 	// String that holds current file line
	        String tmp;
	        
	        // Read first line
	        line = bufRead.readLine();
	        
			// Read through file one line at time. Print line # and line
	        Pattern pattern = Pattern.compile("\\<keywords\\>.*\\<\\/keywords\\>");
	        
	        // if a match is found, we'll replace all commas followed by spaces with just commas
	        Pattern p = Pattern.compile(",\\s*");
	       
	        while (line != null){
	        	Matcher matcher = pattern.matcher(line);
	        	while(matcher.find()){
	        		String match = matcher.group();
	        		String m = p.matcher(match).replaceAll(",");		
	        		keywords = m.substring(m.indexOf(">")+1, m.indexOf("</")).split(",");
	        		
	        		//fix case for keywords
	        		for (int i = 0; i < keywords.length; i++){
	        			tmp = CapWords(keywords[i]);
	        			//showToast(tmp, null);
	        			keywords[i] = tmp;
	        		}
	        	}
	            line = bufRead.readLine();
	        }
	        
	        bufRead.close();
		}catch(IOException e){
			e.printStackTrace();
		}
		return keywords;
	}

    
	/**
	 * Copies a given file to the best directory where it fits best based on some keywords
	 * @param ff file to be copied to the best directory
	 */
    public void MoveFileToBestPath(String ff){ 
    	String[] bp = BestPath(ExtractKeywords(ff));
    	String best_path = bp[1];
    	String file_folder = bp[0];
    	
    	if (best_path != null){
    		// check if the path exists
    		best_path = "sdcard/Ontology/" + best_path;
    		File dir = new File(best_path);
    		
    		if((dir.exists() && dir.isDirectory()) == false) {
    		    // create the directory
    			dir.mkdirs();
    		}
    		
    		File f = new File(ff);
	    	File dest = new File(best_path + f.getName());
	    	try {
				copy(f, dest);
				showToast("File has been moved to '" + best_path + "'", null);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				showToast("Failed to move file", null);
				e.printStackTrace();
			}
			
			// Add the file to the AllFiles table 
			try{
				ContentValues values = new ContentValues();
				values.put("filename", f.getName());
				values.put("pid", file_folder);
				getContentResolver().insert(getIntent().getData(), values);
			}catch(Exception e){
				e.printStackTrace();
			}
			
    	}else{
    		showToast("Best path could not be resolved for file :(", null);
    	}
    }
    
    /**
     * Scans a given directory for files and moves them under the best directory they belong to
     * under the user's Ontology
     */
    public void GetNewFiles(){
    	String PATH = "sdcard/Downloads/";
    	File dir = new File(PATH);

    	//String[] children = dir.list();
    	FilenameFilter filter = new FilenameFilter() {
    	    public boolean accept(File dir, String name) {
    	        return name.endsWith(".txt");
    	    }
    	};
    	String[] children = dir.list(filter);
    	
    	if (children == null) {
    	    // Either dir does not exist or is not a directory
    		showToast("No new files found", null);
    	} else {
    		// Return first text file found
    	    for (int i=0; i<children.length; i++) {
    	        // Get filename of file or directory
    	        String filename = children[i];
    	        showToast("Found: " + filename, null);
    	        if (ExtractKeywords(PATH + filename) != null){
    	        	MoveFileToBestPath(PATH + filename);
    	        }
    	    }
    	}
    }
    
    /**
     * Copies a file from source to destination
     * @param src directory where the file will be copied from
     * @param dst directory where the file will be copied to
     * @throws IOException
     */
    public void copy(File src, File dst) throws IOException {
    	// Copies a file from source to destination
    	
        InputStream in = new FileInputStream(src);
        OutputStream out = new FileOutputStream(dst);

        // Transfer bytes from in to out
        byte[] buf = new byte[1024];
        int len;
        while ((len = in.read(buf)) > 0) {
            out.write(buf, 0, len);
        }
        in.close();
        out.close();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
        case MENU_ITEM_INSERT:
            // Launch activity to insert a new item
            //startActivity(new Intent(Intent.ACTION_INSERT, getIntent().getData()));
        	NewNode();
            return true;
        case MENU_ITEM_EXPORT:
        	try {
				SaveOWL("sdcard/Ontology/Ontology.owl");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return true;
        case MENU_ITEM_SCAN:
        	// scan for new files
        	GetNewFiles();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View view, ContextMenuInfo menuInfo) {
        AdapterView.AdapterContextMenuInfo info;
        try {
             info = (AdapterView.AdapterContextMenuInfo) menuInfo;
        } catch (ClassCastException e) {
            Log.e(TAG, "bad menuInfo", e);
            return;
        }

        Cursor cursor = (Cursor) getListAdapter().getItem(info.position);
        if (cursor == null) {
            // For some reason the requested item isn't available, do nothing
            return;
        }

        // Setup the menu header
        menu.setHeaderTitle(cursor.getString(COLUMN_INDEX_TITLE));

        // Add a menu item to delete the note
        menu.add(0, MENU_ITEM_DELETE, 0, R.string.menu_delete);
        menu.add(1, MENU_ITEM_SHOWFILES, 0,"Show Files");
    }
        
    @Override
    public boolean onContextItemSelected(MenuItem item) {
        AdapterView.AdapterContextMenuInfo info;
        try {
             info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        } catch (ClassCastException e) {
            Log.e(TAG, "bad menuInfo", e);
            return false;
        }

        switch (item.getItemId()) {
            case MENU_ITEM_DELETE: {
                // Delete the note that the context menu is for
                Uri noteUri = ContentUris.withAppendedId(getIntent().getData(), info.id);
                getContentResolver().delete(noteUri, null, null);
                return true;
            }
        }
        return false;
    }

    @Override
    protected void onListItemClick(ListView l, View v, int position, long id) {
        Uri uri = ContentUris.withAppendedId(getIntent().getData(), id);
        
        String action = getIntent().getAction();
        if (Intent.ACTION_PICK.equals(action) || Intent.ACTION_GET_CONTENT.equals(action)) {
            // The caller is waiting for us to return a note selected by
            // the user.  The have clicked on one, so return it now.
            setResult(RESULT_OK, new Intent().setData(uri));
        } else {
            // Launch activity to view/edit the currently selected item
        	String node = l.getAdapter().getItem(position).toString();
        	Intent myIntent = new Intent();
        	Bundle bundle = new Bundle();
        	bundle.putLong("id", id);
        	bundle.putString("parent", node);
        	myIntent.putExtras(bundle);
        	// set the new intent to the current intent
        	myIntent.setClass(NotesList.this, NotesList.class);
        	startActivity(myIntent);
        }
    }
}
